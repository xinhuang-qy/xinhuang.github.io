// custom.js

// 页面加载完毕执行
$(function () {
    // 所有删除和移除按钮确认提示
    $('a.btn-danger').click(function (e) {
        return confirm('您确定要执行此操作吗？');
    });

    // 你可以这里添加更多通用的 JS 代码，比如表单验证、AJAX请求等
});
