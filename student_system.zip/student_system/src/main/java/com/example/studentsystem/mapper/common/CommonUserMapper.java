package com.example.studentsystem.mapper.common;

import com.example.studentsystem.pojo.User;
import org.apache.ibatis.annotations.Param;

public interface CommonUserMapper {

    /**
     * 根据学号或工号查询用户及角色信息
     *
     * @param account 学号或工号
     * @return User对象，包含角色信息
     */
    User findByStudentNumberOrEmployeeNumber(@Param("account") String account);
}
