package com.example.studentsystem.controller.admin;

import com.example.studentsystem.pojo.ClassCourse;
import com.example.studentsystem.pojo.Course;
import com.example.studentsystem.pojo.Class;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.admin.ClassCourseService;
import com.example.studentsystem.service.admin.ClassService;
import com.example.studentsystem.service.admin.CourseService;
import com.example.studentsystem.service.admin.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/courses")
public class AdminCourseController {

    @Autowired
    private CourseService courseService;
    @Autowired
    private ClassCourseService classCourseService;
    @Autowired
    private ClassService classService;
    @Autowired
    private UserService userService;

    // 1. 原课程管理页面
    @GetMapping("")
    public String listCourses(Model model) {
        List<Course> courses = courseService.getAllCourses();
        model.addAttribute("courses", courses);
        return "admin/course/list";
    }

    @GetMapping("/add")
    public String toAdd() {
        return "admin/course/add";
    }

    @PostMapping("/add")
    public String addCourse(Course course) {
        courseService.addCourse(course);
        return "redirect:/admin/courses";
    }

    @GetMapping("/edit/{id}")
    public String toEdit(@PathVariable Integer id, Model model) {
        Course course = courseService.getCourseById(id);
        model.addAttribute("course", course);
        return "admin/course/edit";
    }

    @PostMapping("/edit")
    public String editCourse(Course course) {
        courseService.updateCourse(course);
        return "redirect:/admin/courses";
    }

    @GetMapping("/delete/{id}")
    public String deleteCourse(@PathVariable Integer id) {
        courseService.deleteCourseById(id);
        return "redirect:/admin/courses";
    }

    // 2. 进入“设置班级课程教师”页面
    @GetMapping("/assign")
    public String toAssignPage(Model model) {
        model.addAttribute("courses", courseService.getAllCourses());
        model.addAttribute("classes", classService.getAllClasses());
        Map<String, Object> params = new HashMap<>();
        params.put("role", "teacher");
        model.addAttribute("teachers", userService.getUsers(params));
        return "admin/course/assign";
    }

    @PostMapping("/assign")
    public String assignCourse(ClassCourse classCourse) {
        classCourseService.addClassCourse(classCourse);
        return "redirect:/admin/courses/assign/list";
    }

    // 3. 展示所有已分配的班级-课程-教师
    @GetMapping("/assign/list")
    public String listAssignments(Model model) {
        List<ClassCourse> list = classCourseService.getAllClassCourses();
        model.addAttribute("assignments", list);
        return "admin/course/assign_list";
    }

    @GetMapping("/assign/delete/{id}")
    public String deleteAssignment(@PathVariable Integer id) {
        classCourseService.deleteClassCourse(id);
        return "redirect:/admin/courses/assign/list";
    }
}
