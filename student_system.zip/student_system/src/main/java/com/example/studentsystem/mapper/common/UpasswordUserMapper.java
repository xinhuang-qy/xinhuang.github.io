package com.example.studentsystem.mapper.common;

import com.example.studentsystem.pojo.User;
import org.apache.ibatis.annotations.Param;

public interface UpasswordUserMapper {
    int updatePassword(@Param("id") Integer id, @Param("newPassword") String newPassword);

    User findById(@Param("id") Integer id);
}
