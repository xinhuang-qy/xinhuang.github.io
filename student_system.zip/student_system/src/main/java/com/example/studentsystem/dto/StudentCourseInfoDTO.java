package com.example.studentsystem.dto;

public class StudentCourseInfoDTO {
    private String courseName;
    private String teacherName;
    private Integer credit;
    private Integer period;

    // Getter & Setter
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }

    public Integer getCredit() { return credit; }
    public void setCredit(Integer credit) { this.credit = credit; }

    public Integer getPeriod() { return period; }
    public void setPeriod(Integer period) { this.period = period; }
}
