package com.example.studentsystem.service.teacher;

import com.example.studentsystem.dto.TeacherCourseInfoDTO;
import com.example.studentsystem.dto.TeacherScoreDTO;
import com.example.studentsystem.pojo.Teacher;

import java.util.List;

public interface TeacherService {
    Teacher getTeacherByUserId(Integer userId);

    List<TeacherCourseInfoDTO> getCourseInfoByTeacherId(Integer teacherId);

    List<TeacherScoreDTO> getScoresByTeacherAndConditions(Integer teacherId, String className, String studentNumber, String courseName);

    // 新增：更新成绩，权限验证在Service层实现
    boolean updateScore(Integer teacherId, Integer scoreId, Double score);
}
