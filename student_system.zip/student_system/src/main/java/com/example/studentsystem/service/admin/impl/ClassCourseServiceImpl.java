package com.example.studentsystem.service.admin.impl;

import com.example.studentsystem.mapper.admin.ClassCourseMapper;
import com.example.studentsystem.pojo.ClassCourse;
import com.example.studentsystem.service.admin.ClassCourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClassCourseServiceImpl implements ClassCourseService {

    @Autowired
    private ClassCourseMapper classCourseMapper;

    @Override
    public List<ClassCourse> getAllClassCourses() {
        return classCourseMapper.getAllClassCourses();
    }

    @Override
    public ClassCourse getClassCourseById(Integer id) {
        return classCourseMapper.getClassCourseById(id);
    }

    @Override
    public void addClassCourse(ClassCourse classCourse) {
        // 1. 插入班级-课程-教师关系
        classCourseMapper.addClassCourse(classCourse);

        // 2. 为该班级所有学生添加初始化成绩记录（score 为空，is_abnormal 为 0）
        classCourseMapper.insertEmptyScoresForClassCourse(classCourse.getId(), classCourse.getClassId());
    }

    @Override
    public void updateClassCourse(ClassCourse classCourse) {
        classCourseMapper.updateClassCourse(classCourse);
    }

    @Override
    public void deleteClassCourse(Integer id) {
        // 1. 删除该班级课程对应的所有学生成绩记录
        classCourseMapper.deleteScoresByClassCourseId(id);

        // 2. 删除班级课程关系
        classCourseMapper.deleteClassCourse(id);
    }
}