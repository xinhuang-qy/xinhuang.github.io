package com.example.studentsystem.controller.student;

import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.common.PasswordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/student/password")
public class StudentPasswordController {

    @Autowired
    private PasswordService passwordService;

    @GetMapping
    public String showPasswordForm(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loginUser");
        if (user == null || !"student".equals(user.getRole())) {
            return "redirect:/common/login";
        }
        return "student/password";
    }

    @PostMapping
    public String updatePassword(@RequestParam("oldPassword") String oldPassword,
                                 @RequestParam("newPassword") String newPassword,
                                 HttpSession session,
                                 Model model) {
        User user = (User) session.getAttribute("loginUser");
        if (user == null || !"student".equals(user.getRole())) {
            return "redirect:/common/login";
        }

        boolean success = passwordService.updatePassword(user.getId(), oldPassword, newPassword);
        if (success) {
            session.invalidate(); // 密码修改成功后登出
            model.addAttribute("message", "密码修改成功，请重新登录");
            return "redirect:/common/login";
        } else {
            model.addAttribute("error", "原密码错误，请重试");
            return "student/password";
        }
    }
}
