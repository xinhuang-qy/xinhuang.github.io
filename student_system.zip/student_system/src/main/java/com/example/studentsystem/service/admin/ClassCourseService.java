package com.example.studentsystem.service.admin;

import com.example.studentsystem.pojo.ClassCourse;
import java.util.List;

public interface ClassCourseService {
    List<ClassCourse> getAllClassCourses();
    ClassCourse getClassCourseById(Integer id);
    void addClassCourse(ClassCourse classCourse);
    void updateClassCourse(ClassCourse classCourse);
    void deleteClassCourse(Integer id);
}
