package com.example.studentsystem.controller.common;

import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.common.CommonUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;  // 使用 javax.servlet 版本

@Controller
@RequestMapping("/common")
public class LoginController {

    private final CommonUserService userService;

    @Autowired
    public LoginController(CommonUserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String loginPage() {
        return "common/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam("account") String account,
                        @RequestParam("password") String password,
                        Model model,
                        HttpSession session) {

        if (account == null || account.isEmpty() || password == null || password.isEmpty()) {
            model.addAttribute("error", "账号和密码不能为空");
            return "common/login";
        }

        User user = userService.findByAccount(account);

        if (user == null) {
            model.addAttribute("error", "账号不存在");
            return "common/login";
        }

        if (!password.equals(user.getPassword())) {
            model.addAttribute("error", "密码错误");
            return "common/login";
        }

        if (!"student".equalsIgnoreCase(user.getRole()) && !"teacher".equalsIgnoreCase(user.getRole())) {
            model.addAttribute("error", "此账号无权通过此页面登录");
            return "common/login";
        }

        session.setAttribute("loginUser", user);

        if ("student".equalsIgnoreCase(user.getRole())) {
            return "redirect:/student/home";
        } else {
            return "redirect:/teacher/home";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/common/login";
    }
}
