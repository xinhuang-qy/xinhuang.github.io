package com.example.studentsystem.service.admin.impl;

import com.example.studentsystem.mapper.admin.AdminUserMapper;
import com.example.studentsystem.pojo.AdminUser;
import com.example.studentsystem.service.admin.AdminUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminUserServiceImpl implements AdminUserService {
    @Autowired
    private AdminUserMapper mapper;

    @Override
    public AdminUser login(String username, String password) {
        AdminUser user = mapper.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    @Override
    @Transactional
    public void changePassword(Integer id, String newPassword) {
        mapper.updatePassword(id, newPassword);
    }
}