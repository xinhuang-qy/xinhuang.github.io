package com.example.studentsystem.mapper.admin;

import com.example.studentsystem.pojo.Major;
import java.util.List;

public interface MajorMapper {
    List<Major> getAllMajors();

    int addMajor(Major major);

    int updateMajor(Major major);

    int deleteMajorById(Integer id);

    Major getMajorById(Integer id);

    List<Class> getClassesByMajorId(Integer majorId);

}
