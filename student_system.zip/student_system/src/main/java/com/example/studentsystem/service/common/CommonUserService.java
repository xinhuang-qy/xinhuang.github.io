package com.example.studentsystem.service.common;

import com.example.studentsystem.pojo.User;

public interface CommonUserService {

    /**
     * 根据学号或工号查找用户
     */
    User findByAccount(String account);
}
