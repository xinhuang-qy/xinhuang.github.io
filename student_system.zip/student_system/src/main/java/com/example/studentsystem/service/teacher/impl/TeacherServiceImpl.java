package com.example.studentsystem.service.teacher.impl;

import com.example.studentsystem.dto.TeacherCourseInfoDTO;
import com.example.studentsystem.dto.TeacherScoreDTO;
import com.example.studentsystem.mapper.teacher.TeacherMapper;
import com.example.studentsystem.pojo.Teacher;
import com.example.studentsystem.service.teacher.TeacherService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Resource
    private TeacherMapper teacherMapper;

    @Override
    public Teacher getTeacherByUserId(Integer userId) {
        return teacherMapper.findTeacherDetailByUserId(userId);
    }

    @Override
    public List<TeacherCourseInfoDTO> getCourseInfoByTeacherId(Integer teacherId) {
        return teacherMapper.findCourseInfoByTeacherId(teacherId);
    }

    @Override
    public List<TeacherScoreDTO> getScoresByTeacherAndConditions(Integer teacherId, String className, String studentNumber, String courseName) {
        return teacherMapper.findScoresByTeacherAndConditions(teacherId, className, studentNumber, courseName);
    }

    @Override
    public boolean updateScore(Integer teacherId, Integer scoreId, Double score) {
        // 先判断该成绩是否属于该教师授课
        Integer count = teacherMapper.checkScoreBelongsToTeacher(teacherId, scoreId);
        if (count == null || count == 0) {
            return false;
        }

        int rows = teacherMapper.updateScore(scoreId, score);
        return rows > 0;
    }
}
