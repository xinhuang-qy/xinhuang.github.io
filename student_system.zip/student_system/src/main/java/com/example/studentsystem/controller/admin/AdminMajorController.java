package com.example.studentsystem.controller.admin;

import com.example.studentsystem.pojo.Major;
import com.example.studentsystem.service.admin.MajorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/majors")  // 改成复数形式，和菜单对应
public class AdminMajorController {

    @Autowired
    private MajorService majorService;

    // 显示专业列表页面，访问 /admin/majors 即可显示列表
    @GetMapping("")
    public String listMajors(Model model) {
        List<Major> majors = majorService.getAllMajors();
        model.addAttribute("majors", majors);
        return "admin/major/list"; // JSP路径：WEB-INF/jsp/admin/major/list.jsp
    }

    // 跳转新增专业页面
    @GetMapping("/add")
    public String toAdd() {
        return "admin/major/add"; // JSP路径：WEB-INF/jsp/admin/major/add.jsp
    }

    // 新增专业提交
    @PostMapping("/add")
    public String addMajor(Major major) {
        majorService.addMajor(major);
        return "redirect:/admin/majors";  // 注意这里改成复数路径
    }

    // 跳转编辑专业页面
    @GetMapping("/edit/{id}")
    public String toEdit(@PathVariable Integer id, Model model) {
        Major major = majorService.getMajorById(id);
        model.addAttribute("major", major);
        return "admin/major/edit"; // JSP路径：WEB-INF/jsp/admin/major/edit.jsp
    }

    // 编辑专业提交
    @PostMapping("/edit")
    public String editMajor(Major major) {
        majorService.updateMajor(major);
        return "redirect:/admin/majors";  // 这里也改成复数路径
    }

    // 删除专业
    @GetMapping("/delete/{id}")
    public String deleteMajor(@PathVariable Integer id) {
        majorService.deleteMajorById(id);
        return "redirect:/admin/majors";  // 这里也改成复数路径
    }

    @GetMapping("/classes/{majorId}")
    public String listClassesByMajor(@PathVariable Integer majorId, Model model) {
        Major major = majorService.getMajorById(majorId);
        List<Class> classes = majorService.getClassesByMajorId(majorId);
        model.addAttribute("major", major);
        model.addAttribute("classes", classes);
        return "admin/major/classes"; // 新增JSP页面，展示班级列表并按年级分组
    }

}
