package com.example.studentsystem.service.student;

import com.example.studentsystem.dto.ScoreQueryDTO;
import com.example.studentsystem.dto.StudentCourseInfoDTO;
import com.example.studentsystem.pojo.Student;

import java.util.List;

public interface StudentService {
    Student getStudentDetailByUserId(Integer userId);
    List<StudentCourseInfoDTO> getCourseInfoByStudentId(Integer studentId);
    List<ScoreQueryDTO> getScoresByStudentAndCourseName(Integer studentId, String courseName);
}