package com.example.studentsystem.controller.admin;

import com.example.studentsystem.pojo.User;
import com.example.studentsystem.pojo.Class;
import com.example.studentsystem.service.admin.UserService;
import com.example.studentsystem.service.admin.ClassService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/admin/user")
public class UserController {

    @Resource
    private UserService userService;
    @Resource
    private ClassService classService;

    @GetMapping({"", "/"})
    public String redirectToList() {
        return "redirect:/admin/user/list";
    }

    @GetMapping("/list")
    public String list(@RequestParam(required = false) String role,
                       @RequestParam(required = false) String studentNumber,
                       @RequestParam(required = false) String employeeNumber,
                       @RequestParam(defaultValue = "1") int page,
                       @RequestParam(defaultValue = "10") int size,
                       Model model) {

        // 优先使用精确查找：只要填写学号或工号，无论是否选择角色
        if (studentNumber != null && !studentNumber.isBlank()) {
            User user = userService.getUserByRoleAndNumber("student", studentNumber);
            return buildUserListModel(model, user, 1, size, "student", studentNumber, null);
        }
        if (employeeNumber != null && !employeeNumber.isBlank()) {
            User user = userService.getUserByRoleAndNumber("teacher", employeeNumber);
            return buildUserListModel(model, user, 1, size, "teacher", null, employeeNumber);
        }

        int offset = (page - 1) * size;
        if (offset < 0) offset = 0;

        var params = new java.util.HashMap<String, Object>();
        params.put("role", role);
        params.put("keyword", null);  // 关键字无效，用 role + number 精确查
        params.put("limit", size);
        params.put("offset", offset);

        List<User> users = userService.getUsers(params);
        int total = userService.countUsers(params);

        model.addAttribute("users", users);
        model.addAttribute("total", total);
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("role", role);
        model.addAttribute("studentNumber", null);
        model.addAttribute("employeeNumber", null);
        return "admin/user/userList";
    }

    private String buildUserListModel(Model model, User user, int page, int size,
                                      String role, String studentNumber, String employeeNumber) {
        List<User> result = (user == null ? List.of() : List.of(user));
        model.addAttribute("users", result);
        model.addAttribute("total", result.size());
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("role", role);
        model.addAttribute("studentNumber", studentNumber);
        model.addAttribute("employeeNumber", employeeNumber);
        return "admin/user/userList";
    }

    @GetMapping("/add")
    public String addPage(Model model) {
        List<Class> classList = classService.getAllClasses();
        model.addAttribute("classList", classList);
        return "admin/user/userAdd";
    }

    @PostMapping("/add")
    public String add(User user,
                      @RequestParam(required = false) String studentNumber,
                      @RequestParam(required = false) Integer classId,
                      @RequestParam(required = false) String employeeNumber,
                      Model model) {
        if (user.getUsername() == null || user.getUsername().isBlank()) {
            model.addAttribute("error", "用户名不能为空");
            model.addAttribute("classList", classService.getAllClasses());
            return "admin/user/userAdd";
        }
        userService.addUserWithRole(user, studentNumber, classId, employeeNumber);
        return "redirect:/admin/user/list";
    }

    @GetMapping("/edit/{id}")
    public String editPage(@PathVariable int id, Model model) {
        User user = userService.getUserById(id);
        model.addAttribute("user", user);
        model.addAttribute("classList", classService.getAllClasses());

        if ("student".equals(user.getRole())) {
            model.addAttribute("classId", user.getClassId());
            model.addAttribute("studentNumber", user.getStudentNumber());
        } else if ("teacher".equals(user.getRole())) {
            model.addAttribute("employeeNumber", user.getEmployeeNumber());
        }
        return "admin/user/userEdit";
    }

    @PostMapping("/edit")
    public String edit(User user,
                       @RequestParam(required = false) String studentNumber,
                       @RequestParam(required = false) Integer classId,
                       @RequestParam(required = false) String employeeNumber,
                       Model model) {
        if (user.getUsername() == null || user.getUsername().isBlank()) {
            model.addAttribute("error", "用户名不能为空");
            model.addAttribute("classList", classService.getAllClasses());
            model.addAttribute("user", user); // 回显数据
            return "admin/user/userEdit";
        }

        userService.updateUserWithRole(user, studentNumber, classId, employeeNumber);

        // ✅ 修改为重定向到 GET /admin/user/edit/{id}
        return "redirect:/admin/user/edit/" + user.getId() + "?success=true";

    }


    @GetMapping("/delete/{id}")
    public String delete(@PathVariable int id) {
        userService.deleteUser(id);
        return "redirect:/admin/user/list";
    }
}