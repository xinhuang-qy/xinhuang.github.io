package com.example.studentsystem.mapper.student;

import com.example.studentsystem.dto.ScoreQueryDTO;
import com.example.studentsystem.dto.StudentCourseInfoDTO;
import com.example.studentsystem.pojo.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface StudentMapper {
    Student findStudentDetailByUserId(@Param("userId") Integer userId);
    List<StudentCourseInfoDTO> findCourseInfoByStudentId(@Param("studentId") Integer studentId);
    List<ScoreQueryDTO> findScoresByStudentIdAndCourseName(@Param("studentId") Integer studentId,
                                                           @Param("courseName") String courseName);
}