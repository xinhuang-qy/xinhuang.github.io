package com.example.studentsystem.controller.teacher;

import com.example.studentsystem.dto.TeacherCourseInfoDTO;
import com.example.studentsystem.dto.TeacherScoreDTO;
import com.example.studentsystem.pojo.Teacher;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.teacher.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Resource
    private TeacherService teacherService;

    @GetMapping("/home")
    public String teacherHome(HttpSession session, Model model) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null || !"teacher".equalsIgnoreCase(loginUser.getRole())) {
            return "redirect:/common/login";
        }

        Integer userId = loginUser.getId();
        Teacher teacher = teacherService.getTeacherByUserId(userId);
        model.addAttribute("teacher", teacher);

        List<TeacherCourseInfoDTO> courseList = teacherService.getCourseInfoByTeacherId(userId);
        model.addAttribute("courseList", courseList);

        return "teacher/home";
    }

    // 成绩管理页面（查询 + 显示 + 录入/修改）
    @GetMapping("/scoreManage")
    public String scoreManage(HttpSession session,
                              Model model,
                              @RequestParam(required = false) String className,
                              @RequestParam(required = false) String studentNumber,
                              @RequestParam(required = false) String courseName) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null || !"teacher".equalsIgnoreCase(loginUser.getRole())) {
            return "redirect:/common/login";
        }

        Integer userId = loginUser.getId();

        List<TeacherScoreDTO> scoreList = teacherService.getScoresByTeacherAndConditions(userId, className, studentNumber, courseName);
        model.addAttribute("scoreList", scoreList);

        model.addAttribute("className", className);
        model.addAttribute("studentNumber", studentNumber);
        model.addAttribute("courseName", courseName);

        return "teacher/scoreManage";
    }

    // 录入或修改成绩接口（AJAX 或表单提交）
    @PostMapping("/updateScore")
    @ResponseBody
    public String updateScore(HttpSession session,
                              @RequestParam Integer scoreId,
                              @RequestParam Double score) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null || !"teacher".equalsIgnoreCase(loginUser.getRole())) {
            return "未登录或无权限";
        }

        Integer userId = loginUser.getId();
        boolean success = teacherService.updateScore(userId, scoreId, score);
        return success ? "success" : "fail";
    }
}
