package com.example.studentsystem.controller.admin;

import com.example.studentsystem.pojo.ScoreView;
import com.example.studentsystem.service.admin.ScoreAuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/scores")
public class ScoreAuditController {

    @Autowired
    private ScoreAuditService scoreAuditService;

    /**
     * 成绩审核页面，支持根据班级号（classNumber）、学号、课程名、是否异常筛选，分页显示
     *
     * @param classNumber  班级号（对应数据库表 class 的 class_number 字段）
     * @param studentNumber 学号
     * @param courseName   课程名
     * @param isAbnormal   异常状态，0-否，1-是，null-全部
     * @param page         当前页码，默认1
     * @param size         每页条数，默认10
     * @param model        Spring MVC 模型，用于传数据到视图
     * @return 页面路径
     */
    @GetMapping
    public String scoreAuditPage(@RequestParam(required = false) String classNumber,
                                 @RequestParam(required = false) String studentNumber,
                                 @RequestParam(required = false) String courseName,
                                 @RequestParam(required = false) Integer isAbnormal,
                                 @RequestParam(defaultValue = "1") int page,
                                 @RequestParam(defaultValue = "10") int size,
                                 Model model) {
        Boolean abnormal = null;
        if (isAbnormal != null) {
            abnormal = isAbnormal == 1;
        }
        // 调用Service查询成绩列表和总数
        List<ScoreView> scores = scoreAuditService.getAllScores(classNumber, studentNumber, courseName, abnormal, page, size);
        int totalCount = scoreAuditService.getTotalCount(classNumber, studentNumber, courseName, abnormal);
        int totalPage = (totalCount + size - 1) / size;

        // 向视图传递参数
        model.addAttribute("scores", scores);
        model.addAttribute("classNumber", classNumber);
        model.addAttribute("studentNumber", studentNumber);
        model.addAttribute("courseName", courseName);
        model.addAttribute("isAbnormal", isAbnormal);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPage", totalPage);

        return "admin/score/audit";
    }

    /**
     * 异常状态更新接口，前端ajax调用，传入成绩id和新的异常状态，更新数据库
     *
     * @param id         成绩id
     * @param isAbnormal 新异常状态，0-非异常，1-异常
     * @return 字符串表示更新结果，success、invalid_status、not_found、invalid_range、not_updated、error
     */
    @PostMapping("/updateAbnormal")
    @ResponseBody
    public String updateAbnormalStatus(@RequestParam Integer id, @RequestParam Integer isAbnormal) {
        try {
            if (isAbnormal != 0 && isAbnormal != 1) {
                return "invalid_status";
            }
            ScoreView score = scoreAuditService.getScoreById(id);
            if (score == null) {
                return "not_found";
            }
            // 取消异常时成绩必须合法
            if (isAbnormal == 0 && (score.getScore() < 0 || score.getScore() > score.getMaxScore())) {
                return "invalid_range";
            }
            int updatedRows = scoreAuditService.updateAbnormalStatus(id, isAbnormal == 1);
            return updatedRows > 0 ? "success" : "not_updated";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }
}
