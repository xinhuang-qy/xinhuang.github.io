package com.example.studentsystem.controller.admin;

import com.example.studentsystem.pojo.AdminUser;
import com.example.studentsystem.service.admin.AdminUserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/admin")
public class AdminLoginController {

    @Autowired
    private AdminUserService service;

    @GetMapping("/login")
    public String loginPage() {
        return "admin/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {
        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            model.addAttribute("error", "用户名和密码不能为空");
            return "admin/login";
        }

        AdminUser user = service.login(username, password);
        if (user != null) {
            session.setAttribute("adminUser", user);
            return "redirect:/admin/dashboard";
        } else {
            model.addAttribute("error", "用户名或密码错误");
            return "admin/login";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "admin/dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/admin/login";
    }

    @GetMapping("/changePassword")
    public String changePasswordPage() {
        return "admin/changePassword";
    }

    @PostMapping("/changePassword")
    public String changePassword(@RequestParam String newPassword,
                                 HttpSession session,
                                 Model model) {
        AdminUser user = (AdminUser) session.getAttribute("adminUser");
        if (user != null) {
            service.changePassword(user.getId(), newPassword);
            model.addAttribute("msg", "密码修改成功");
        } else {
            model.addAttribute("error", "未登录");
            return "admin/login";
        }
        return "admin/changePassword";
    }
}
