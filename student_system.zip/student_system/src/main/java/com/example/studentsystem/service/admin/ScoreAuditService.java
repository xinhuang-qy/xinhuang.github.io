package com.example.studentsystem.service.admin;

import com.example.studentsystem.pojo.ScoreView;

import java.util.List;

/**
 * 管理员端成绩审核业务接口
 */
public interface ScoreAuditService {

    /**
     * 分页查询成绩列表，支持按班级号、学号、课程名、异常状态筛选
     * @param classNumber 班级号，模糊匹配
     * @param studentNumber 学号，模糊匹配
     * @param courseName 课程名，模糊匹配
     * @param isAbnormal 异常状态过滤，true/false/null(全部)
     * @param page 当前页码，从1开始
     * @param size 每页记录数
     * @return 成绩视图列表
     */
    List<ScoreView> getAllScores(String classNumber, String studentNumber, String courseName, Boolean isAbnormal, int page, int size);

    /**
     * 查询符合条件的成绩总数，用于分页
     */
    int getTotalCount(String classNumber, String studentNumber, String courseName, Boolean isAbnormal);

    /**
     * 更新某条成绩的异常标记状态
     */
    int updateAbnormalStatus(Integer id, Boolean isAbnormal);

    /**
     * 根据成绩ID获取详细成绩视图
     */
    ScoreView getScoreById(Integer id);
}
