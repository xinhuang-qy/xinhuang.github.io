package com.example.studentsystem.service.admin;

import com.example.studentsystem.pojo.Class;
import com.example.studentsystem.pojo.User;

import java.util.List;

public interface ClassService {

    // 班级管理相关功能
    List<Class> getClasses(String grade, Integer majorId, int offset, int limit);
    int countClasses(String grade, Integer majorId);
    Class getClassById(int id);
    void addClass(Class clazz);
    void updateClass(Class clazz);
    void deleteClass(int id);
    List<Class> getAllClasses();

    // ===== 新增：班级学生管理相关功能 =====

    /**
     * 获取指定班级下的学生列表
     */
    List<User> getStudentsByClassId(int classId);

    /**
     * 将指定学生加入到某班级
     */
    void addStudentToClass(int studentId, int classId);

    /**
     * 将学生从班级中移除
     */
    void removeStudentFromClass(int studentId);

    /**
     * 查询未加入任何班级的学生
     */
    List<User> getStudentsWithoutClass();
}
