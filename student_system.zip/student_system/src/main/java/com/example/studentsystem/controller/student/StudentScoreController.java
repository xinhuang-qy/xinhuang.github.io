package com.example.studentsystem.controller.student;

import com.example.studentsystem.dto.ScoreQueryDTO;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.student.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/student/score")
public class StudentScoreController {

    @Autowired
    private StudentService studentService;

    @GetMapping
    public String queryScore(@RequestParam(value = "courseName", required = false) String courseName,
                             HttpSession session, Model model) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null || !"student".equals(loginUser.getRole())) {
            return "redirect:/common/login";
        }

        List<ScoreQueryDTO> scoreList = studentService.getScoresByStudentAndCourseName(loginUser.getId(), courseName);
        model.addAttribute("scoreList", scoreList);
        model.addAttribute("courseName", courseName);
        return "student/score";
    }
}
