package com.example.studentsystem.mapper.admin;

import com.example.studentsystem.pojo.ClassCourse;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ClassCourseMapper {
    List<ClassCourse> getAllClassCourses();

    ClassCourse getClassCourseById(Integer id);

    void addClassCourse(ClassCourse classCourse);

    void updateClassCourse(ClassCourse classCourse);

    void deleteClassCourse(Integer id);

    // ✅ 新增：插入所有学生初始成绩
    void insertEmptyScoresForClassCourse(@Param("classCourseId") Integer classCourseId,
                                         @Param("classId") Integer classId);

    // ✅ 新增：删除班级课程下所有成绩
    void deleteScoresByClassCourseId(@Param("classCourseId") Integer classCourseId);

    // 根据班级id查询班级课程列表
    List<ClassCourse> getClassCoursesByClassId(@Param("classId") Integer classId);

    // 插入某学生的某课程空成绩
    void insertEmptyScoreForStudent(@Param("studentId") Integer studentId,
                                    @Param("classCourseId") Integer classCourseId);

    // 删除某学生的某课程成绩
    void deleteScoreByStudentAndClassCourse(@Param("studentId") Integer studentId,
                                            @Param("classCourseId") Integer classCourseId);
}
