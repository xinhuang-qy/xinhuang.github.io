package com.example.studentsystem.pojo;

public class Class {
    private Integer id;
    private String className;
    private Integer grade;
    private Integer majorId;
    private String classNumber;

    private String majorName;

    // getters and setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    public Integer getGrade() { return grade; }
    public void setGrade(Integer grade) { this.grade = grade; }
    public Integer getMajorId() { return majorId; }
    public void setMajorId(Integer majorId) { this.majorId = majorId; }
    public String getClassNumber() { return classNumber; }
    public void setClassNumber(String classNumber) { this.classNumber = classNumber; }
    public String getMajorName() { return majorName; }
    public void setMajorName(String majorName) { this.majorName = majorName; }
}