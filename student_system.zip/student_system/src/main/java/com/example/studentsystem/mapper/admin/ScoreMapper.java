package com.example.studentsystem.mapper.admin;

import com.example.studentsystem.pojo.ScoreView;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ScoreMapper {
    List<ScoreView> getAllScores(@Param("classNumber") String classNumber,
                                 @Param("studentNumber") String studentNumber,
                                 @Param("courseName") String courseName,
                                 @Param("isAbnormal") Boolean isAbnormal,
                                 @Param("offset") int offset,
                                 @Param("size") int size);

    int getScoreCount(@Param("classNumber") String classNumber,
                      @Param("studentNumber") String studentNumber,
                      @Param("courseName") String courseName,
                      @Param("isAbnormal") Boolean isAbnormal);

    int updateAbnormalStatus(@Param("id") Integer id, @Param("isAbnormal") Boolean isAbnormal);

    ScoreView getScoreById(@Param("id") Integer id);
}
