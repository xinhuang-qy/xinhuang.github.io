package com.example.studentsystem.mapper.admin;

import com.example.studentsystem.pojo.Course;
import java.util.List;

public interface CourseMapper {
    List<Course> getAllCourses();
    Course getCourseById(Integer id);
    void addCourse(Course course);
    void updateCourse(Course course);
    void deleteCourseById(Integer id);
}
