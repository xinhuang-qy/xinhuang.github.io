package com.example.studentsystem.service.common.impl;

import com.example.studentsystem.mapper.common.CommonUserMapper;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.common.CommonUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("commonUserServiceImpl")
public class CommonUserServiceImpl implements CommonUserService {

    private final CommonUserMapper userMapper;

    @Autowired
    public CommonUserServiceImpl(CommonUserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public User findByAccount(String account) {
        return userMapper.findByStudentNumberOrEmployeeNumber(account);
    }
}
