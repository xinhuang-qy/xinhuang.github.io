package com.example.studentsystem.service.common;

public interface PasswordService {
    boolean updatePassword(Integer userId, String oldPassword, String newPassword);
}
