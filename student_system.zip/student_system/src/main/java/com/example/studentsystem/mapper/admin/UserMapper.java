package com.example.studentsystem.mapper.admin;

import com.example.studentsystem.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface UserMapper {
    void addUser(User user);

    void updateUser(User user);

    void updateUserWithPassword(User user);

    void updateUserWithoutPassword(User user);

    void deleteUser(int id);

    List<User> getUsers(Map<String, Object> params);

    int countUsers(Map<String, Object> params);

    User getUserById(int id);

    void addStudentWithClass(@Param("id") int id,
                             @Param("studentNumber") String studentNumber,
                             @Param("classId") Integer classId);

    void updateStudentWithClass(@Param("id") int id,
                                @Param("studentNumber") String studentNumber,
                                @Param("classId") Integer classId);

    void deleteStudentById(int id);

    void addTeacher(@Param("id") int id,
                    @Param("employeeNumber") String employeeNumber);

    void updateTeacher(@Param("id") int id,
                       @Param("employeeNumber") String employeeNumber);

    void deleteTeacherById(int id);

    Integer getStudentClassIdByUserId(int userId);

    // 新增：删除某学生所有成绩
    void deleteScoresByStudentId(@Param("studentId") Integer studentId);
}
