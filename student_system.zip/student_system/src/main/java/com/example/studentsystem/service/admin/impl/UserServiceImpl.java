package com.example.studentsystem.service.admin.impl;

import com.example.studentsystem.mapper.admin.ClassCourseMapper;
import com.example.studentsystem.mapper.admin.UserMapper;
import com.example.studentsystem.pojo.ClassCourse;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.admin.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private ClassCourseMapper classCourseMapper; // 注入班级课程Mapper

    @Override
    public Integer getStudentClassIdByUserId(int userId) {
        return userMapper.getStudentClassIdByUserId(userId);
    }

    @Override
    public void addUser(User user) {
        userMapper.addUser(user);
    }

    @Override
    public void updateUser(User user) {
        userMapper.updateUser(user);
    }

    @Override
    public void deleteUser(int id) {
        User user = getUserById(id);
        if (user != null) {
            if ("student".equals(user.getRole())) {
                // 删除学生成绩记录
                userMapper.deleteScoresByStudentId(id);
                // 删除学生扩展信息
                userMapper.deleteStudentById(id);
            } else if ("teacher".equals(user.getRole())) {
                userMapper.deleteTeacherById(id);
            }
            // 删除用户基本信息
            userMapper.deleteUser(id);
        }
    }

    @Override
    public List<User> getUsers(Map<String, Object> params) {
        if (!params.containsKey("limit") || params.get("limit") == null) {
            params.put("limit", 10);
        }
        if (!params.containsKey("offset") || params.get("offset") == null) {
            params.put("offset", 0);
        }
        return userMapper.getUsers(params);
    }

    @Override
    public int countUsers(Map<String, Object> params) {
        return userMapper.countUsers(params);
    }

    @Override
    public User getUserById(int id) {
        return userMapper.getUserById(id);
    }

    @Override
    public void addUserWithRole(User user, String studentNumber, Integer classId, String employeeNumber) {
        userMapper.addUser(user);
        Integer userId = user.getId();

        if ("student".equals(user.getRole())) {
            // 添加学生扩展信息
            userMapper.addStudentWithClass(userId, studentNumber, classId);

            // 查询该班级所有课程
            List<ClassCourse> classCourses = classCourseMapper.getClassCoursesByClassId(classId);

            // 初始化该学生所有课程成绩（score为空，is_abnormal=0）
            for (ClassCourse cc : classCourses) {
                classCourseMapper.insertEmptyScoreForStudent(userId, cc.getId());
            }

        } else if ("teacher".equals(user.getRole())) {
            userMapper.addTeacher(userId, employeeNumber);
        }
    }

    @Override
    public void updateUserWithRole(User user, String studentNumber, Integer newClassId, String employeeNumber) {
        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            userMapper.updateUserWithoutPassword(user);
        } else {
            userMapper.updateUserWithPassword(user);
        }

        if ("student".equals(user.getRole())) {
            // 先查旧班级id
            Integer oldClassId = userMapper.getStudentClassIdByUserId(user.getId());

            // 更新学生扩展信息（包括班级）
            userMapper.updateStudentWithClass(user.getId(), studentNumber, newClassId);

            if (oldClassId != null && !oldClassId.equals(newClassId)) {
                // 班级发生变更时，同步成绩：

                // 1. 删除该学生在旧班级课程的所有成绩
                // 先查询旧班级课程
                List<ClassCourse> oldClassCourses = classCourseMapper.getClassCoursesByClassId(oldClassId);
                for (ClassCourse cc : oldClassCourses) {
                    classCourseMapper.deleteScoreByStudentAndClassCourse(user.getId(), cc.getId());
                }

                // 2. 查询新班级课程
                List<ClassCourse> newClassCourses = classCourseMapper.getClassCoursesByClassId(newClassId);

                // 3. 为该学生初始化新班级所有课程的成绩记录
                for (ClassCourse cc : newClassCourses) {
                    classCourseMapper.insertEmptyScoreForStudent(user.getId(), cc.getId());
                }
            }

        } else if ("teacher".equals(user.getRole())) {
            userMapper.updateTeacher(user.getId(), employeeNumber);
        }
    }

    @Override
    public User getUserByRoleAndNumber(String role, String number) {
        if (role == null || number == null) return null;
        Map<String, Object> params = new HashMap<>();
        params.put("role", role);
        params.put("keyword", number);

        List<User> users = userMapper.getUsers(params);
        if (users != null && !users.isEmpty()) {
            return users.get(0);
        }
        return null;
    }
}
