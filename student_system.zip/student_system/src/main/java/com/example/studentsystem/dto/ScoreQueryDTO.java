package com.example.studentsystem.dto;

public class ScoreQueryDTO {
    private String courseName;
    private Integer score;
    private Boolean abnormal;       // 代替 isAbnormal
    private Integer credit;         // 加上credit字段
    private String teacherName;     // 加上teacherName字段

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public Integer getScore() { return score; }
    public void setScore(Integer score) { this.score = score; }

    public Boolean getAbnormal() { return abnormal; }
    public void setAbnormal(Boolean abnormal) { this.abnormal = abnormal; }

    public Integer getCredit() { return credit; }
    public void setCredit(Integer credit) { this.credit = credit; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }
}
