package com.example.studentsystem.service.common.impl;

import com.example.studentsystem.mapper.common.UpasswordUserMapper;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.common.PasswordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PasswordServiceImpl implements PasswordService {

    @Autowired
    private UpasswordUserMapper userMapper;

    @Override
    public boolean updatePassword(Integer userId, String oldPassword, String newPassword) {
        User user = userMapper.findById(userId);
        if (user == null || !user.getPassword().equals(oldPassword)) {
            return false;
        }
        return userMapper.updatePassword(userId, newPassword) > 0;
    }
}
