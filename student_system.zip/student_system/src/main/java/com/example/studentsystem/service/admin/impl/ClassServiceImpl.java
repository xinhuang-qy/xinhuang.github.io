package com.example.studentsystem.service.admin.impl;

import com.example.studentsystem.mapper.admin.ClassMapper;
import com.example.studentsystem.pojo.Class;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.admin.ClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClassServiceImpl implements ClassService {

    private final ClassMapper classMapper;

    @Autowired
    public ClassServiceImpl(ClassMapper classMapper) {
        this.classMapper = classMapper;
    }

    @Override
    public List<Class> getClasses(String grade, Integer majorId, int offset, int limit) {
        return classMapper.getClasses(grade, majorId, offset, limit);
    }

    @Override
    public int countClasses(String grade, Integer majorId) {
        return classMapper.countClasses(grade, majorId);
    }

    @Override
    public Class getClassById(int id) {
        return classMapper.getClassById(id);
    }

    @Override
    public void addClass(Class clazz) {
        classMapper.addClass(clazz);
    }

    @Override
    public void updateClass(Class clazz) {
        classMapper.updateClass(clazz);
    }

    @Override
    public void deleteClass(int id) {
        classMapper.deleteClass(id);
    }

    @Override
    public List<Class> getAllClasses() {
        return classMapper.getAllClasses();
    }

    // ===== 新增方法实现 =====

    @Override
    public List<User> getStudentsByClassId(int classId) {
        return classMapper.getStudentsByClassId(classId);
    }

    @Override
    public void addStudentToClass(int studentId, int classId) {
        classMapper.updateStudentClassId(studentId, classId);
    }

    @Override
    public void removeStudentFromClass(int studentId) {
        classMapper.updateStudentClassId(studentId, null);
    }

    @Override
    public List<User> getStudentsWithoutClass() {
        return classMapper.getStudentsWithoutClass();
    }
}
