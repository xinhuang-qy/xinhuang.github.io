package com.example.studentsystem.mapper.admin;

import com.example.studentsystem.pojo.Class;
import com.example.studentsystem.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ClassMapper {

    // 分页条件查询班级列表
    List<Class> getClasses(@Param("grade") String grade,
                           @Param("majorId") Integer majorId,
                           @Param("offset") int offset,
                           @Param("limit") int limit);

    // 统计符合条件的班级数量
    int countClasses(@Param("grade") String grade,
                     @Param("majorId") Integer majorId);

    // 根据班级ID获取班级信息
    Class getClassById(@Param("id") int id);

    // 新增班级
    void addClass(Class clazz);

    // 修改班级信息
    void updateClass(Class clazz);

    // 删除班级
    void deleteClass(@Param("id") int id);

    // 获取所有班级列表（无条件）
    List<Class> getAllClasses();

    // 查询某个班级的所有学生
    List<User> getStudentsByClassId(@Param("classId") int classId);

    // 更新学生的班级ID（添加或移除学生班级）
    void updateStudentClassId(@Param("studentId") int studentId,
                              @Param("classId") Integer classId);

    // 查询未加入任何班级的学生
    List<User> getStudentsWithoutClass();
}
