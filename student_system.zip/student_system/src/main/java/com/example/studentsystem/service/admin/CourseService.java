package com.example.studentsystem.service.admin;

import com.example.studentsystem.pojo.Course;
import java.util.List;

public interface CourseService {
    List<Course> getAllCourses();
    Course getCourseById(Integer id);
    void addCourse(Course course);
    void updateCourse(Course course);
    void deleteCourseById(Integer id);
}

