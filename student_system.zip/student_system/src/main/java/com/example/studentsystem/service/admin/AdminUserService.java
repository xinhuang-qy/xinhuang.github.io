package com.example.studentsystem.service.admin;

import com.example.studentsystem.pojo.AdminUser;

public interface AdminUserService {
    AdminUser login(String username, String password);
    void changePassword(Integer id, String newPassword);
}