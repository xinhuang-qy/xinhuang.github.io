package com.example.studentsystem.service.admin.impl;

import com.example.studentsystem.mapper.admin.ScoreMapper;
import com.example.studentsystem.pojo.ScoreView;
import com.example.studentsystem.service.admin.ScoreAuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 管理员端成绩审核业务实现类
 */
@Service
public class ScoreAuditServiceImpl implements ScoreAuditService {

    @Autowired
    private ScoreMapper scoreMapper;

    /**
     * 实现分页查询，计算offset后调用Mapper
     */
    @Override
    public List<ScoreView> getAllScores(String classNumber, String studentNumber, String courseName, Boolean isAbnormal, int page, int size) {
        int offset = (page - 1) * size;
        return scoreMapper.getAllScores(classNumber, studentNumber, courseName, isAbnormal, offset, size);
    }

    /**
     * 查询满足条件的成绩总数
     */
    @Override
    public int getTotalCount(String classNumber, String studentNumber, String courseName, Boolean isAbnormal) {
        return scoreMapper.getScoreCount(classNumber, studentNumber, courseName, isAbnormal);
    }

    /**
     * 更新异常状态
     */
    @Override
    public int updateAbnormalStatus(Integer id, Boolean isAbnormal) {
        return scoreMapper.updateAbnormalStatus(id, isAbnormal);
    }

    /**
     * 根据id查询成绩详情
     */
    @Override
    public ScoreView getScoreById(Integer id) {
        return scoreMapper.getScoreById(id);
    }
}
