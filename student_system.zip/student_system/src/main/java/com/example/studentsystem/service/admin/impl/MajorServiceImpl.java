package com.example.studentsystem.service.admin.impl;

import com.example.studentsystem.mapper.admin.MajorMapper;
import com.example.studentsystem.pojo.Major;
import com.example.studentsystem.service.admin.MajorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MajorServiceImpl implements MajorService {

    @Autowired
    private MajorMapper majorMapper;

    @Override
    public List<Major> getAllMajors() {
        return majorMapper.getAllMajors();
    }

    @Override
    public int addMajor(Major major) {
        return majorMapper.addMajor(major);
    }

    @Override
    public int updateMajor(Major major) {
        return majorMapper.updateMajor(major);
    }

    @Override
    public int deleteMajorById(Integer id) {
        return majorMapper.deleteMajorById(id);
    }

    @Override
    public Major getMajorById(Integer id) {
        return majorMapper.getMajorById(id);
    }

    @Override
    public List<Class> getClassesByMajorId(Integer majorId) {
        return majorMapper.getClassesByMajorId(majorId);
    }

}
