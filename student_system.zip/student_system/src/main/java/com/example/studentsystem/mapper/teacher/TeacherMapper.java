package com.example.studentsystem.mapper.teacher;

import com.example.studentsystem.dto.TeacherCourseInfoDTO;
import com.example.studentsystem.dto.TeacherScoreDTO;
import com.example.studentsystem.pojo.Teacher;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TeacherMapper {
    Teacher findTeacherDetailByUserId(@Param("userId") Integer userId);

    List<TeacherCourseInfoDTO> findCourseInfoByTeacherId(@Param("teacherId") Integer teacherId);

    int checkScoreBelongsToTeacher(@Param("teacherId") Integer teacherId, @Param("scoreId") Integer scoreId);

    int updateScore(@Param("scoreId") Integer scoreId, @Param("score") Double score);


    List<TeacherScoreDTO> findScoresByTeacherAndConditions(@Param("teacherId") Integer teacherId,
                                                           @Param("className") String className,
                                                           @Param("studentNumber") String studentNumber,
                                                           @Param("courseName") String courseName);
}
