package com.example.studentsystem.pojo;

public class Course {
    private Integer id;
    private String courseName;
    private Integer credit;
    private Integer period;

    // Getter 和 Setter
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public Integer getCredit() { return credit; }
    public void setCredit(Integer credit) { this.credit = credit; }

    public Integer getPeriod() { return period; }
    public void setPeriod(Integer period) { this.period = period; }
}
