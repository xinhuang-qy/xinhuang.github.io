package com.example.studentsystem.mapper.admin;

import com.example.studentsystem.pojo.AdminUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;


@Mapper
public interface AdminUserMapper {
    AdminUser findByUsername(@Param("username") String username);
    int insert(AdminUser user);
    int updatePassword(@Param("id") Integer id, @Param("password") String password);
}