package com.example.studentsystem.service.admin;

import com.example.studentsystem.pojo.User;

import java.util.List;
import java.util.Map;

public interface UserService {
    void addUser(User user);
    void updateUser(User user);
    void deleteUser(int id);

    List<User> getUsers(Map<String, Object> params);
    int countUsers(Map<String, Object> params);

    User getUserById(int id);
    Integer getStudentClassIdByUserId(int userId);

    // 新增接口，支持扩展信息插入/更新
    void addUserWithRole(User user, String studentNumber, Integer classId, String employeeNumber);
    void updateUserWithRole(User user, String studentNumber, Integer classId, String employeeNumber);

    // 新增：根据角色和学号/工号精确查询单个用户
    User getUserByRoleAndNumber(String role, String number);
}
