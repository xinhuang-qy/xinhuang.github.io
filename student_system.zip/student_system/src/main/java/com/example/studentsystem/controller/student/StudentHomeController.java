package com.example.studentsystem.controller.student;

import com.example.studentsystem.dto.StudentCourseInfoDTO;
import com.example.studentsystem.pojo.Student;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.student.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentHomeController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/home")
    public String studentHome(HttpSession session, Model model) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null || !"student".equalsIgnoreCase(loginUser.getRole())) {
            return "redirect:/common/login";
        }

        Student studentDetail = studentService.getStudentDetailByUserId(loginUser.getId());
        List<StudentCourseInfoDTO> courseList = studentService.getCourseInfoByStudentId(loginUser.getId());

        model.addAttribute("student", studentDetail);
        model.addAttribute("courseList", courseList);

        return "student/home";
    }
}
