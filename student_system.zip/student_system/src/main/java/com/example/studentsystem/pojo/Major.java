package com.example.studentsystem.pojo;

public class Major {
    private Integer id;
    private String majorName;

    public Major() {}

    public Major(Integer id, String majorName) {
        this.id = id;
        this.majorName = majorName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMajorName() {
        return majorName;
    }

    public void setMajorName(String majorName) {
        this.majorName = majorName;
    }
}
