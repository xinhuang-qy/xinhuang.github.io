package com.example.studentsystem.controller.admin;

import com.example.studentsystem.pojo.Class;
import com.example.studentsystem.pojo.Major;
import com.example.studentsystem.pojo.User;
import com.example.studentsystem.service.admin.ClassService;
import com.example.studentsystem.service.admin.MajorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class ClassController {

    private final ClassService classService;
    private final MajorService majorService;

    @Autowired
    public ClassController(ClassService classService, MajorService majorService) {
        this.classService = classService;
        this.majorService = majorService;
    }

    // --- 班级管理相关 ---

    @GetMapping("/classes")
    public String listClasses(@RequestParam(defaultValue = "1") int page,
                              @RequestParam(defaultValue = "10") int pageSize,
                              @RequestParam(required = false) String grade,
                              @RequestParam(required = false) Integer majorId,
                              Model model) {
        int offset = (page - 1) * pageSize;
        List<Class> classes = classService.getClasses(grade, majorId, offset, pageSize);
        int total = classService.countClasses(grade, majorId);

        List<Major> majors = majorService.getAllMajors();

        model.addAttribute("classes", classes);
        model.addAttribute("page", page);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("total", total);
        model.addAttribute("grade", grade);
        model.addAttribute("majorId", majorId);
        model.addAttribute("majors", majors);

        return "admin/class/classList"; // 调整路径
    }

    @GetMapping("/classes/add")
    public String addClassForm(Model model) {
        model.addAttribute("majors", majorService.getAllMajors());
        return "admin/class/classAdd";  // 调整路径
    }

    @PostMapping("/classes/add")
    public String addClass(Class clazz) {
        classService.addClass(clazz);
        return "redirect:/admin/classes";
    }

    @GetMapping("/classes/edit/{id}")
    public String editClassForm(@PathVariable int id, Model model) {
        Class clazz = classService.getClassById(id);
        if (clazz == null) {
            return "redirect:/admin/classes";
        }
        model.addAttribute("clazz", clazz);
        model.addAttribute("majors", majorService.getAllMajors());
        return "admin/class/classEdit";  // 调整路径
    }

    @PostMapping("/classes/edit")
    public String editClass(Class clazz) {
        classService.updateClass(clazz);
        return "redirect:/admin/classes";
    }

    @GetMapping("/classes/delete/{id}")
    public String deleteClass(@PathVariable int id) {
        classService.deleteClass(id);
        return "redirect:/admin/classes";
    }

    // ===== 班级学生管理相关 =====

    /**
     * 查看某班级学生列表
     */
    @GetMapping("/classes/{classId}/students")
    public String listStudentsInClass(@PathVariable int classId, Model model) {
        Class clazz = classService.getClassById(classId);
        if (clazz == null) {
            return "redirect:/admin/classes";
        }

        List<User> students = classService.getStudentsByClassId(classId);
        model.addAttribute("clazz", clazz);
        model.addAttribute("students", students);
        return "admin/class/classStudents";  // 调整路径
    }

}
