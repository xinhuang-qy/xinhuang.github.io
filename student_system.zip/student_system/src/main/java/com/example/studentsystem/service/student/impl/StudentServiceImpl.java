package com.example.studentsystem.service.student.impl;

import com.example.studentsystem.dto.ScoreQueryDTO;
import com.example.studentsystem.dto.StudentCourseInfoDTO;
import com.example.studentsystem.mapper.student.StudentMapper;
import com.example.studentsystem.pojo.Student;
import com.example.studentsystem.service.student.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentMapper studentMapper;

    @Override
    public Student getStudentDetailByUserId(Integer userId) {
        return studentMapper.findStudentDetailByUserId(userId);
    }

    @Override
    public List<StudentCourseInfoDTO> getCourseInfoByStudentId(Integer studentId) {
        return studentMapper.findCourseInfoByStudentId(studentId);
    }

    @Override
    public List<ScoreQueryDTO> getScoresByStudentAndCourseName(Integer studentId, String courseName) {
        return studentMapper.findScoresByStudentIdAndCourseName(studentId, courseName);
    }
}